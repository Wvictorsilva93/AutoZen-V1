var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employees/invite/route.js")
R.c("server/chunks/[root-of-the-server]__1yv199j._.js")
R.c("server/chunks/node_modules_1lmq98q._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_employees_invite_route_actions_0to58b0.js")
R.m(82332)
module.exports=R.m(82332).exports
