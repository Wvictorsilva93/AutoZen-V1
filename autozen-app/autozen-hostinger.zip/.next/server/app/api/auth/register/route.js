var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__09qhw0x._.js")
R.c("server/chunks/node_modules_1lmq98q._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_0g4vfdr.js")
R.m(89124)
module.exports=R.m(89124).exports
