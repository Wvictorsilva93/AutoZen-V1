module.exports=[65021,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_employees_invite_route_actions_0to58b0.js.map