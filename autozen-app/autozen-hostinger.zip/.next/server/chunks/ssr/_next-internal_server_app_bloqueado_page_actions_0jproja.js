module.exports=[518,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bloqueado_page_actions_0jproja.js.map