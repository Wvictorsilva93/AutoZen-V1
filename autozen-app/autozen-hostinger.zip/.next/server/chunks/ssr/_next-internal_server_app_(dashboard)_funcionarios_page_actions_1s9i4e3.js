module.exports=[71253,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_funcionarios_page_actions_1s9i4e3.js.map