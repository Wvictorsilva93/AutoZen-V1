module.exports=[73688,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_fotos_page_actions_08h5zzy.js.map