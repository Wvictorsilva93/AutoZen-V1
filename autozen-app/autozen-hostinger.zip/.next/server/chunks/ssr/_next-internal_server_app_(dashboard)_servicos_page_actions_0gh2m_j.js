module.exports=[90438,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_servicos_page_actions_0gh2m_j.js.map