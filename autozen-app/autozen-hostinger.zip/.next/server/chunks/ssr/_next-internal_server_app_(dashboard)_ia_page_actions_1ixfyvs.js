module.exports=[9934,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_ia_page_actions_1ixfyvs.js.map