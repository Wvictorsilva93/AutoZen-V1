module.exports=[77934,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_clientes_page_actions_1qhnyt8.js.map