module.exports=[25460,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_estoque_page_actions_1kw6fp0.js.map