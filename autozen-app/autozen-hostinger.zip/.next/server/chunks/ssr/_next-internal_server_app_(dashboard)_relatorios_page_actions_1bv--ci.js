module.exports=[91918,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_relatorios_page_actions_1bv--ci.js.map