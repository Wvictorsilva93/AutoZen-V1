module.exports=[36993,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_financeiro_page_actions_1hbqu-t.js.map