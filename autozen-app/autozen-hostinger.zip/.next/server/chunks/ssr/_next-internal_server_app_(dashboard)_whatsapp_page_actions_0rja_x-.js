module.exports=[26254,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_whatsapp_page_actions_0rja_x-.js.map