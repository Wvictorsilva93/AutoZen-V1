module.exports=[86602,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_ordens_page_actions_1oo2xif.js.map