globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/OgpvY_xqQeC8vGq6o-qh0/_buildManifest.js",
    "static/OgpvY_xqQeC8vGq6o-qh0/_ssgManifest.js",
    "static/OgpvY_xqQeC8vGq6o-qh0/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2kk9zqg5r_gnh.js",
    "static/chunks/08pkoxz3i_qyw.js",
    "static/chunks/2nykiepra7i1k.js",
    "static/chunks/turbopack-3m5yvojmnhl98.js"
  ]
};
