globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/khcYwzjk7urfqUyrg5JPH/_buildManifest.js",
    "static/khcYwzjk7urfqUyrg5JPH/_ssgManifest.js",
    "static/khcYwzjk7urfqUyrg5JPH/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2ljx1crut13_r.js",
    "static/chunks/12ng9y1xmtxdd.js",
    "static/chunks/2oh5rha75m2ak.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-2wnocb_l81jra.js"
  ]
};
