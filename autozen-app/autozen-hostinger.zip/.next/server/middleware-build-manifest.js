globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/0COkb08hM6u9npmgdib31/_buildManifest.js",
    "static/0COkb08hM6u9npmgdib31/_ssgManifest.js",
    "static/0COkb08hM6u9npmgdib31/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1u99p3bfa1_27.js",
    "static/chunks/2asfk0bng_efy.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-0c8_sz_ezb4-v.js"
  ]
};
