globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/fViOTjP_KCbFGFbe03LaT/_buildManifest.js",
    "static/fViOTjP_KCbFGFbe03LaT/_ssgManifest.js",
    "static/fViOTjP_KCbFGFbe03LaT/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3nl9t97_gkez7.js",
    "static/chunks/2asfk0bng_efy.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-293840yo6x-9p.js"
  ]
};
